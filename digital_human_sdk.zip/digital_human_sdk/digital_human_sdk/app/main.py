# import json
# import logging
# import time
# from dotenv import load_dotenv
# from agents import Runner

# # =====================================================
# # 🔥 FORCE LiteLLM Gemini model registration
# # =====================================================
# # IMPORTANT:
# # Importing this module registers get_model_name()
# from digital_human_sdk.app.intelligence.models import litellm_model

# # =====================================================
# # Agents
# # =====================================================
# from digital_human_sdk.app.intelligence.safety.safety_agent import safe_agent
# from digital_human_sdk.app.intelligence.our_agents.router_agent import router_agent
# from digital_human_sdk.app.intelligence.our_agents.memory_agent import memory_agent
# from digital_human_sdk.app.intelligence.our_agents.tool_agent import tool_agent
# from digital_human_sdk.app.intelligence.our_agents.reasoning_agent import reasoning_agent

# # =====================================================
# # Tools
# # =====================================================
# from digital_human_sdk.app.intelligence.contracts.tool_request import ToolRequest
# from digital_human_sdk.app.intelligence.tools.tool_executor import ToolExecutor

# load_dotenv()

# # =====================================================
# # Logger
# # =====================================================

# logging.getLogger("digital_human_sdk").handlers = logging.getLogger().handlers
# logging.getLogger("digital_human_sdk").setLevel(logging.INFO)
# logging.getLogger("digital_human_sdk").propagate = True
# async def run_digital_human_chat(
#     *,
#     user_input: str,
#     chat_history: list,
#     user_config: dict,
# ):
#     """
#     STREAMING ORCHESTRATOR (SDK-only, no DB)

#     Emits:
#       - { type: "token", value: str }
#       - { type: "memory_event", payload: dict }
#     """

#     start_time = time.time()

#     logger.info("🚀 Digital Human chat started")
#     logger.info(f"🧑 User input | {user_input[:200]}")
#     logger.info(f"📚 History size | {len(chat_history)}")
#     logger.info(f"⚙️ User config | {user_config}")

#     # =====================================================
#     # 1️⃣ PRE-SAFETY (input moderation)
#     # =====================================================
#     logger.info("🛡️ Running PRE-safety agent")

#     pre_raw = await Runner.run(
#         safe_agent,
#         user_input,
#         max_turns=1,
#     )

#     raw_pre = (pre_raw.final_output or "").strip()
#     logger.debug(f"🛡️ Pre-safety raw output | {raw_pre}")

#     try:
#         pre = json.loads(raw_pre)
#     except json.JSONDecodeError:
#         logger.warning("⚠️ Pre-safety returned invalid JSON — failing open")
#         pre = {"safe": True}

#     if not pre.get("safe", True):
#         logger.warning("⛔ Input blocked by safety agent")
#         for ch in pre.get("message", "Blocked by safety policy"):
#             yield {"type": "token", "value": ch}
#         return

#     logger.info("✅ Pre-safety passed")

#     # =====================================================
#     # 2️⃣ ROUTER (intent only)
#     # =====================================================
#     logger.info("🧭 Running router agent")

#     router_raw = await Runner.run(router_agent, user_input)
#     logger.debug(f"🧭 Router raw output | {router_raw.final_output}")

#     try:
#         router = json.loads(router_raw.final_output or "{}")
#     except json.JSONDecodeError:
#         logger.warning("⚠️ Router returned invalid JSON")
#         router = {}

#     use_memory = (
#         router.get("use_memory", False)
#         and user_config.get("memory_enabled", False)
#     )

#     use_tool = (
#         router.get("use_tool", False)
#         and user_config.get("tool_enabled", False)
#     )

#     logger.info(
#         f"🧭 Router decision | memory={use_memory} | tool={use_tool}"
#     )

#     memory_context = {}
#     tool_context = {}

#     # =====================================================
#     # 3️⃣ MEMORY AGENT
#     # =====================================================
#     if use_memory:
#         logger.info("🧠 Running memory agent")

#         mem_raw = await Runner.run(memory_agent, user_input)
#         logger.debug(f"🧠 Memory raw output | {mem_raw.final_output}")

#         try:
#             memory_context = json.loads(mem_raw.final_output or "{}")
#             logger.info("🧠 Memory parsed successfully")
#         except json.JSONDecodeError:
#             logger.error("❌ Invalid memory agent JSON")
#             memory_context = {
#                 "status": "error",
#                 "error": "Invalid memory agent output",
#             }

#         # Backend persists memory
#         yield {
#             "type": "memory_event",
#             "payload": memory_context,
#         }

#     else:
#         logger.info("🧠 Memory agent skipped")

#     # =====================================================
#     # 4️⃣ TOOL AGENT
#     # =====================================================
#     if use_tool:
#         logger.info("🛠️ Running tool agent")

#         tool_raw = await Runner.run(tool_agent, user_input)
#         logger.debug(f"🛠️ Tool raw output | {tool_raw.final_output}")

#         try:
#             req_dict = json.loads(tool_raw.final_output)
#             req = ToolRequest(**req_dict)
#             tool_context = ToolExecutor.execute(req).model_dump()

#             logger.info("🛠️ Tool executed successfully")
#         except Exception as e:
#             logger.exception("❌ Tool execution failed")
#             tool_context = {
#                 "status": "error",
#                 "error": str(e),
#             }
#     else:
#         logger.info("🛠️ Tool agent skipped")

#     # =====================================================
#     # 5️⃣ REASONING AGENT (MAIN LLM)
#     # =====================================================
#     reasoning_input = {
#         "user_input": user_input,
#         "chat_history": chat_history,
#         "memory_context": memory_context,
#         "tool_context": tool_context,
#         "capabilities": {
#             "memory_enabled": user_config.get("memory_enabled", False),
#             "tool_enabled": user_config.get("tool_enabled", False),
#         },
#     }

#     logger.info("🧠 Running reasoning agent")

#     reasoning_raw = await Runner.run(
#         reasoning_agent,
#         json.dumps(reasoning_input),
#     )

#     logger.info(
#         f"🧠 Reasoning completed | chars={len(reasoning_raw.final_output or '')}"
#     )

#     # =====================================================
#     # 6️⃣ POST-SAFETY (output moderation)
#     # =====================================================
#     logger.info("🛡️ Running POST-safety agent")

#     post_raw = await Runner.run(
#         safe_agent,
#         reasoning_raw.final_output,
#         max_turns=1,
#     )

#     raw_post = (post_raw.final_output or "").strip()
#     logger.debug(f"🛡️ Post-safety raw output | {raw_post}")

#     try:
#         post = json.loads(raw_post)
#     except json.JSONDecodeError:
#         logger.warning("⚠️ Post-safety returned invalid JSON — failing open")
#         post = {"safe": True}

#     if not post.get("safe", True):
#         logger.warning("⛔ Output blocked by safety agent")
#         for ch in post.get("message", "Response blocked by safety policy"):
#             yield {"type": "token", "value": ch}
#         return

#     logger.info("✅ Post-safety passed")

#     # =====================================================
#     # 7️⃣ STREAM FINAL ANSWER
#     # =====================================================
#     logger.info("📡 Streaming final response")

#     token_count = 0
#     for ch in reasoning_raw.final_output or "":
#         token_count += 1
#         yield {
#             "type": "token",
#             "value": ch,
#         }

#     elapsed = round(time.time() - start_time, 2)
#     logger.info(
#         f"🏁 Stream finished | tokens={token_count} | time={elapsed}s"
#     )
import json
import logging
from dotenv import load_dotenv
from agents import Runner
 
from digital_human_sdk.app.intelligence.safety.safety_agent import safe_agent
from digital_human_sdk.app.intelligence.our_agents.router_agent import router_agent
from digital_human_sdk.app.intelligence.our_agents.memory_agent import memory_agent
from digital_human_sdk.app.intelligence.our_agents.tool_agent import tool_agent
from digital_human_sdk.app.intelligence.our_agents.reasoning_agent import reasoning_agent
 
from digital_human_sdk.app.intelligence.contracts.tool_request import ToolRequest
from digital_human_sdk.app.intelligence.tools.tool_executor import ToolExecutor
 
load_dotenv()
 
logger = logging.getLogger("orchestrator")
logger.setLevel(logging.INFO)
 
 
async def run_digital_human_chat(
    *,
    user_input: str,
    chat_history: list,
    user_config: dict,
):
    # =====================================================
    # 0️⃣ SAFETY (TEXT-BASED)
    # =====================================================
    logger.info("🛡️ Safety agent called")
 
    safety_raw = await Runner.run(safe_agent, user_input)
    safety_text = (safety_raw.final_output or "").lower()
 
    if "cannot" in safety_text or "not allowed" in safety_text:
        logger.warning("🚫 Safety blocked request")
        for ch in safety_raw.final_output:
            yield {"type": "token", "value": ch}
        return
 
    # =====================================================
    # 1️⃣ ROUTER
    # =====================================================
    logger.info("🧭 Router agent called")
 
    router_raw = await Runner.run(router_agent, user_input)
    try:
        console.log("🧭 Router RAW OUTPUT:")
        router = json.loads(router_raw.final_output)
    except Exception:
        logger.error("Router JSON invalid")
       
        router = {"use_tool": False, "use_memory": False}
 
    use_tool = router.get("use_tool", True) and user_config.get("tool_enabled", True)
    use_memory = router.get("use_memory", True) and user_config.get("memory_enabled", True)
 
    logger.info(f"use_tool={use_tool}, use_memory={use_memory}")
 
    memory_context = {}
    tool_context = {}
 
    # =====================================================
    # 2️⃣ MEMORY
    # =====================================================
    if use_memory:
        logger.info("🧠 Memory agent called")
        mem_raw = await Runner.run(memory_agent, user_input)
        try:
            memory_context = json.loads(mem_raw.final_output or "{}")
        except Exception:
            memory_context = {}
 
        yield {"type": "memory_event", "payload": memory_context}
 
    # =====================================================
    # 3️⃣ TOOL
    # =====================================================
    if use_tool:
        logger.info("🛠️ Tool agent called")
        tool_raw = await Runner.run(tool_agent, user_input)
        logger.info(f"RAW_TOOL_OUTPUT={tool_raw.final_output}")
 
        try:
            tool_request = ToolRequest(**json.loads(tool_raw.final_output))
            tool_context = ToolExecutor.execute(tool_request).model_dump()
            logger.info(f"TOOL_RESULT={tool_context}")
        except Exception as e:
            logger.exception("Tool failed")
            tool_context = {"error": str(e)}
 
    # =====================================================
    # 4️⃣ REASONING
    # =====================================================
    logger.info("🧠 Reasoning agent called")
 
    reasoning_input = {
        "user_input": user_input,
        "chat_history": chat_history,
        "memory_context": memory_context,
        "tool_context": tool_context,
        "capabilities": user_config,
    }
 
    reasoning_raw = await Runner.run(
        reasoning_agent,
        json.dumps(reasoning_input),
    )
 
    final_text = reasoning_raw.final_output or ""
 
    # =====================================================
    # 5️⃣ STREAM
    # =====================================================
    for word in final_text.split(" "):
        yield {"type": "token", "value": word + " "}