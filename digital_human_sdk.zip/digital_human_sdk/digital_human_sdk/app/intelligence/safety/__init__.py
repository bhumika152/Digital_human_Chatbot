"""Safety module: guardrails + tools + safe agent."""


